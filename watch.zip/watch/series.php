//season 1
<?php if($values = get_post_custom_values("e1_1")) { ?>
$(".openload1_1").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e1_2")) { ?>
$(".openload1_2").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e1_3")) { ?>
$(".openload1_3").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e1_4")) { ?>
$(".openload1_4").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e1_5")) { ?>
$(".openload1_5").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e1_6")) { ?>
$(".openload1_6").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e1_7")) { ?>
$(".openload1_7").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e1_8")) { ?>
$(".openload1_8").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e1_9")) { ?>
$(".openload1_9").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e1_10")) { ?>
$(".openload1_10").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e1_11")) { ?>
$(".openload1_11").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e1_12")) { ?>
$(".openload1_12").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e1_13")) { ?>
$(".openload1_13").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e1_14")) { ?>
$(".openload1_14").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e1_15")) { ?>
$(".openload1_15").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e1_16")) { ?>
$(".openload1_16").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e1_17")) { ?>
$(".openload1_17").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e1_18")) { ?>
$(".openload1_18").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e1_19")) { ?>
$(".openload1_19").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e1_20")) { ?>
$(".openload1_20").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
//season 2
<?php if($values = get_post_custom_values("e2_1")) { ?>
$(".openload2_1").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e2_2")) { ?>
$(".openload2_2").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e2_3")) { ?>
$(".openload2_3").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e2_4")) { ?>
$(".openload2_4").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e2_5")) { ?>
$(".openload2_5").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e2_6")) { ?>
$(".openload2_6").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e2_7")) { ?>
$(".openload2_7").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e2_8")) { ?>
$(".openload2_8").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e2_9")) { ?>
$(".openload2_9").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e2_10")) { ?>
$(".openload2_10").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e2_11")) { ?>
$(".openload2_11").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e2_12")) { ?>
$(".openload2_12").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e2_13")) { ?>
$(".openload2_13").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e2_14")) { ?>
$(".openload2_14").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e2_15")) { ?>
$(".openload2_15").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e2_16")) { ?>
$(".openload2_16").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e2_17")) { ?>
$(".openload2_17").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e2_18")) { ?>
$(".openload2_18").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e2_19")) { ?>
$(".openload2_19").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e2_20")) { ?>
$(".openload2_20").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
//season 3
<?php if($values = get_post_custom_values("e3_1")) { ?>
$(".openload3_1").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e3_2")) { ?>
$(".openload3_2").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e3_3")) { ?>
$(".openload3_3").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e3_4")) { ?>
$(".openload3_4").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e3_5")) { ?>
$(".openload3_5").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e3_6")) { ?>
$(".openload3_6").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e3_7")) { ?>
$(".openload3_7").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e3_8")) { ?>
$(".openload3_8").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e3_9")) { ?>
$(".openload3_9").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e3_10")) { ?>
$(".openload3_10").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e3_11")) { ?>
$(".openload3_11").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e3_12")) { ?>
$(".openload3_12").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e3_13")) { ?>
$(".openload3_13").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e3_14")) { ?>
$(".openload3_14").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e3_15")) { ?>
$(".openload3_15").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e3_16")) { ?>
$(".openload3_16").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e3_17")) { ?>
$(".openload3_17").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e3_18")) { ?>
$(".openload3_18").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e3_19")) { ?>
$(".openload3_19").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e3_20")) { ?>
$(".openload3_20").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
//season 4
<?php if($values = get_post_custom_values("e4_1")) { ?>
$(".openload4_1").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e4_2")) { ?>
$(".openload4_2").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e4_3")) { ?>
$(".openload4_3").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e4_4")) { ?>
$(".openload4_4").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e4_5")) { ?>
$(".openload4_5").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e4_6")) { ?>
$(".openload4_6").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e4_7")) { ?>
$(".openload4_7").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e4_8")) { ?>
$(".openload4_8").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e4_9")) { ?>
$(".openload4_9").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e4_10")) { ?>
$(".openload4_10").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e4_11")) { ?>
$(".openload4_11").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e4_12")) { ?>
$(".openload4_12").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e4_13")) { ?>
$(".openload4_13").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e4_14")) { ?>
$(".openload4_14").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e4_15")) { ?>
$(".openload4_15").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e4_16")) { ?>
$(".openload4_16").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e4_17")) { ?>
$(".openload4_17").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e4_18")) { ?>
$(".openload4_18").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e4_19")) { ?>
$(".openload4_19").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e4_20")) { ?>
$(".openload4_20").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
//season 5
<?php if($values = get_post_custom_values("e5_1")) { ?>
$(".openload5_1").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e5_2")) { ?>
$(".openload5_2").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e5_3")) { ?>
$(".openload5_3").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e5_4")) { ?>
$(".openload5_4").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e5_5")) { ?>
$(".openload5_5").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e5_6")) { ?>
$(".openload5_6").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e5_7")) { ?>
$(".openload5_7").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e5_8")) { ?>
$(".openload5_8").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e5_9")) { ?>
$(".openload5_9").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e5_10")) { ?>
$(".openload5_10").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e5_11")) { ?>
$(".openload5_11").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e5_12")) { ?>
$(".openload5_12").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e5_13")) { ?>
$(".openload5_13").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e5_14")) { ?>
$(".openload5_14").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e5_15")) { ?>
$(".openload5_15").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e5_16")) { ?>
$(".openload5_16").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e5_17")) { ?>
$(".openload5_17").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e5_18")) { ?>
$(".openload5_18").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e5_19")) { ?>
$(".openload5_19").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e5_20")) { ?>
$(".openload5_20").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
//season 6
<?php if($values = get_post_custom_values("e6_1")) { ?>
$(".openload6_1").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e6_2")) { ?>
$(".openload6_2").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e6_3")) { ?>
$(".openload6_3").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e6_4")) { ?>
$(".openload6_4").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e6_5")) { ?>
$(".openload6_5").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e6_6")) { ?>
$(".openload6_6").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e6_7")) { ?>
$(".openload6_7").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e6_8")) { ?>
$(".openload6_8").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e6_9")) { ?>
$(".openload6_9").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e6_10")) { ?>
$(".openload6_10").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e6_11")) { ?>
$(".openload6_11").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e6_12")) { ?>
$(".openload6_12").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e6_13")) { ?>
$(".openload6_13").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e6_14")) { ?>
$(".openload6_14").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e6_15")) { ?>
$(".openload6_15").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e6_16")) { ?>
$(".openload6_16").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e6_17")) { ?>
$(".openload6_17").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e6_18")) { ?>
$(".openload6_18").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e6_19")) { ?>
$(".openload6_19").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e6_20")) { ?>
$(".openload6_20").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
//season 7
<?php if($values = get_post_custom_values("e7_1")) { ?>
$(".openload7_1").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e7_2")) { ?>
$(".openload7_2").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e7_3")) { ?>
$(".openload7_3").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e7_4")) { ?>
$(".openload7_4").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e7_5")) { ?>
$(".openload7_5").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e7_6")) { ?>
$(".openload7_6").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e7_7")) { ?>
$(".openload7_7").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e7_8")) { ?>
$(".openload7_8").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e7_9")) { ?>
$(".openload7_9").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e7_10")) { ?>
$(".openload7_10").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e7_11")) { ?>
$(".openload7_11").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e7_12")) { ?>
$(".openload7_12").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e7_13")) { ?>
$(".openload7_13").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e7_14")) { ?>
$(".openload7_14").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e7_15")) { ?>
$(".openload7_15").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e7_16")) { ?>
$(".openload7_16").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e7_17")) { ?>
$(".openload7_17").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e7_18")) { ?>
$(".openload7_18").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e7_19")) { ?>
$(".openload7_19").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
<?php if($values = get_post_custom_values("e7_20")) { ?>
$(".openload7_20").append("<iframe id='openload' width='100%' height='340' src='<?php echo $values[0]; ?>' frameborder='0' allowfullscreen=''></iframe>");<?php } else { ?><?php } ?>
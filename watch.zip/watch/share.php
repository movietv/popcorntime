<div id="share_cont" class="share_off">
<div style="width:100%;height:100%;position:relative;">
<div id="share_msg">
<div id="share_txt">
<div id="share_title">Help Our Project Grow!</div>
<div>&nbsp;<img src="<?php echo get_template_directory_uri(); ?>/images/share_fb.png" onclick="_share('fb')">
<img src="<?php echo get_template_directory_uri(); ?>/images/share_twitter.png" onclick="_share('tw')">
<img src="<?php echo get_template_directory_uri(); ?>/images/share_google.png" onclick="_share('goo')">
</div>
</div>
</div>
<img style="position:relative;" src="<?php echo get_template_directory_uri(); ?>/images/share_mascot.png">
</div>
</div>
